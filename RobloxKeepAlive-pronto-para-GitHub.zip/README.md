# Roblox Keep Alive (helper app)

A small Android helper with a dark/blue UI, a Roblox launch shortcut, and shortcuts to Android app/battery settings.

## Important limitation
This app does not keep Roblox's process alive, prevent Android from suspending it, or prevent Roblox from disconnecting. Android does not provide ordinary third-party apps a supported way to force another app to keep running with the screen off. The helper only makes the relevant settings easier to reach.

## Build
Requires Android SDK and Gradle 8.9+ with JDK 17. Run `gradle assembleDebug`; APK output is `app/build/outputs/apk/debug/app-debug.apk`.
A GitHub Actions workflow is included to build the APK and publish it as a workflow artifact when this project is pushed to GitHub.
