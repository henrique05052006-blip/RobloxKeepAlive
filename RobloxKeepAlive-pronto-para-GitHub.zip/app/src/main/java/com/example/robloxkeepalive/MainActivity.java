package com.example.robloxkeepalive;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String ROBLOX_PACKAGE = "com.roblox.client";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView status = findViewById(R.id.status);
        Button open = findViewById(R.id.openRoblox);
        Button robloxSettings = findViewById(R.id.robloxSettings);
        Button batterySettings = findViewById(R.id.batterySettings);

        open.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage(ROBLOX_PACKAGE);
            if (launch != null) {
                status.setText("Abrindo Roblox…");
                startActivity(launch);
            } else {
                status.setText("Roblox não encontrado. Instale-o pela loja oficial.");
            }
        });

        robloxSettings.setOnClickListener(v -> {
            try {
                Intent details = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + ROBLOX_PACKAGE));
                startActivity(details);
            } catch (Exception e) {
                status.setText("Não foi possível abrir as configurações do Roblox.");
            }
        });

        batterySettings.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });
    }
}
